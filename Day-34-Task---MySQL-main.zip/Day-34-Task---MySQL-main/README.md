In this task, created a database for the Guvi Zen Class with Entity Relationship Diagram.
